package com.yeqifu.bus.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yeqifu.bus.entity.Communication;
import com.yeqifu.bus.mapper.CommunicationMapper;
import com.yeqifu.bus.service.ICommunicationService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 在线沟通管理 服务实现类
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
@Service
public class CommunicationServiceImpl extends ServiceImpl<CommunicationMapper, Communication> implements ICommunicationService {

}
