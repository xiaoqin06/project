package com.yeqifu.bus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yeqifu.bus.entity.Communication;

/**
 * <p>
 * 在线沟通管理 服务类
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
public interface ICommunicationService extends IService<Communication> {

}
