package com.yeqifu.bus.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yeqifu.bus.entity.Stocktaking;
import com.yeqifu.bus.mapper.StocktakingMapper;
import com.yeqifu.bus.service.IStocktakingService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 货物盘点管理 服务实现类
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
@Service
public class StocktakingServiceImpl extends ServiceImpl<StocktakingMapper, Stocktaking> implements IStocktakingService {

}
