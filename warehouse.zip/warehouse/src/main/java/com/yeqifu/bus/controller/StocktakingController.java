package com.yeqifu.bus.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yeqifu.bus.entity.Goods;
import com.yeqifu.bus.entity.Stocktaking;
import com.yeqifu.bus.service.IGoodsService;
import com.yeqifu.bus.service.IStocktakingService;
import com.yeqifu.bus.vo.StocktakingVo;
import com.yeqifu.sys.common.DataGridView;
import com.yeqifu.sys.common.ResultObj;
import com.yeqifu.sys.common.WebUtils;
import com.yeqifu.sys.entity.User;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * <p>
 * 货物盘点管理 前端控制器
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
@RestController
@RequestMapping("/stocktaking")
public class StocktakingController {

    @Autowired
    private IStocktakingService stocktakingService;

    @Autowired
    private IGoodsService goodsService;

    /**
     * 查询所有货物盘点记录
     */
    @RequestMapping("loadAllStocktaking")
    public DataGridView loadAllStocktaking(StocktakingVo stocktakingVo) {
        IPage<Stocktaking> page = new Page<>(stocktakingVo.getPage(), stocktakingVo.getLimit());
        QueryWrapper<Stocktaking> queryWrapper = new QueryWrapper<>();
        queryWrapper.like(StringUtils.isNotBlank(stocktakingVo.getGoodsName()), "goods_name", stocktakingVo.getGoodsName());
        queryWrapper.like(StringUtils.isNotBlank(stocktakingVo.getStocktakingMonth()), "stocktaking_month", stocktakingVo.getStocktakingMonth());
        queryWrapper.eq(stocktakingVo.getGoodsId() != null, "goods_id", stocktakingVo.getGoodsId());
        queryWrapper.orderByDesc("create_time");
        stocktakingService.page(page, queryWrapper);
        return new DataGridView(page.getTotal(), page.getRecords());
    }

    /**
     * 添加货物盘点记录
     */
    @RequestMapping("addStocktaking")
    public ResultObj addStocktaking(StocktakingVo stocktakingVo) {
        try {
            if (stocktakingVo.getGoodsId() != null) {
                Goods goods = goodsService.getById(stocktakingVo.getGoodsId());
                if (goods != null) {
                    stocktakingVo.setGoodsName(goods.getGoodsname());
                    stocktakingVo.setSystemNumber(goods.getNumber());
                }
            }
            if (stocktakingVo.getActualNumber() != null && stocktakingVo.getSystemNumber() != null) {
                stocktakingVo.setDifferenceNumber(stocktakingVo.getActualNumber() - stocktakingVo.getSystemNumber());
            }
            stocktakingVo.setCreateTime(new Date());
            stocktakingVo.setAvailable(1);
            User user = (User) WebUtils.getSession().getAttribute("user");
            if (user != null) {
                stocktakingVo.setOperator(user.getName());
            }
            stocktakingService.save(stocktakingVo);
            return ResultObj.ADD_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.ADD_ERROR;
        }
    }

    /**
     * 修改货物盘点记录
     */
    @RequestMapping("updateStocktaking")
    public ResultObj updateStocktaking(StocktakingVo stocktakingVo) {
        try {
            if (stocktakingVo.getActualNumber() != null && stocktakingVo.getSystemNumber() != null) {
                stocktakingVo.setDifferenceNumber(stocktakingVo.getActualNumber() - stocktakingVo.getSystemNumber());
            }
            stocktakingService.updateById(stocktakingVo);
            return ResultObj.UPDATE_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.UPDATE_ERROR;
        }
    }

    /**
     * 删除货物盘点记录
     */
    @RequestMapping("deleteStocktaking")
    public ResultObj deleteStocktaking(Integer id) {
        try {
            stocktakingService.removeById(id);
            return ResultObj.DELETE_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.DELETE_ERROR;
        }
    }

    /**
     * 批量删除货物盘点记录
     */
    @RequestMapping("batchDeleteStocktaking")
    public ResultObj batchDeleteStocktaking(StocktakingVo stocktakingVo) {
        try {
            stocktakingService.removeById(stocktakingVo.getId());
            return ResultObj.DELETE_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.DELETE_ERROR;
        }
    }

}
