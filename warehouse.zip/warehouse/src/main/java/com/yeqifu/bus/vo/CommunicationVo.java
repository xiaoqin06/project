package com.yeqifu.bus.vo;

import com.yeqifu.bus.entity.Communication;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * <p>
 * 在线沟通管理VO
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ToString
public class CommunicationVo extends Communication {

    private Integer page = 1;
    private Integer limit = 10;

}
