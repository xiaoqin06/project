package com.yeqifu.bus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yeqifu.bus.entity.Communication;

/**
 * <p>
 * 在线沟通管理 Mapper 接口
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
public interface CommunicationMapper extends BaseMapper<Communication> {

}
