package com.yeqifu.bus.service;

import com.yeqifu.bus.entity.Inport;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * InnoDB free: 9216 kB; (`providerid`) REFER `warehouse/bus_provider`(`id`); (`goo 服务类
 * </p>
 *
 * @author luoyi-
 * @since 2019-12-18
 */
public interface IInportService extends IService<Inport> {

}
