package com.yeqifu.bus.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yeqifu.bus.entity.Communication;
import com.yeqifu.bus.entity.Provider;
import com.yeqifu.bus.service.ICommunicationService;
import com.yeqifu.bus.service.IProviderService;
import com.yeqifu.bus.vo.CommunicationVo;
import com.yeqifu.sys.common.DataGridView;
import com.yeqifu.sys.common.ResultObj;
import com.yeqifu.sys.common.WebUtils;
import com.yeqifu.sys.entity.User;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * <p>
 * 在线沟通管理 前端控制器
 * </p>
 *
 * @author yeqifu
 * @since 2024-01-01
 */
@RestController
@RequestMapping("/communication")
public class CommunicationController {

    @Autowired
    private ICommunicationService communicationService;

    @Autowired
    private IProviderService providerService;

    /**
     * 查询所有在线沟通记录
     */
    @RequestMapping("loadAllCommunication")
    public DataGridView loadAllCommunication(CommunicationVo communicationVo) {
        IPage<Communication> page = new Page<>(communicationVo.getPage(), communicationVo.getLimit());
        QueryWrapper<Communication> queryWrapper = new QueryWrapper<>();
        queryWrapper.like(StringUtils.isNotBlank(communicationVo.getTitle()), "title", communicationVo.getTitle());
        queryWrapper.like(StringUtils.isNotBlank(communicationVo.getProviderName()), "provider_name", communicationVo.getProviderName());
        queryWrapper.like(StringUtils.isNotBlank(communicationVo.getEmployeeName()), "employee_name", communicationVo.getEmployeeName());
        queryWrapper.eq(communicationVo.getStatus() != null, "status", communicationVo.getStatus());
        queryWrapper.eq(communicationVo.getProviderId() != null, "provider_id", communicationVo.getProviderId());
        queryWrapper.eq(communicationVo.getEmployeeId() != null, "employee_id", communicationVo.getEmployeeId());
        queryWrapper.orderByDesc("create_time");
        communicationService.page(page, queryWrapper);
        return new DataGridView(page.getTotal(), page.getRecords());
    }

    /**
     * 添加在线沟通记录
     */
    @RequestMapping("addCommunication")
    public ResultObj addCommunication(CommunicationVo communicationVo) {
        try {
            communicationVo.setCreateTime(new Date());
            communicationVo.setStatus(0);
            communicationVo.setAvailable(1);
            User user = (User) WebUtils.getSession().getAttribute("user");
            if (user != null) {
                communicationVo.setEmployeeName(user.getName());
                communicationVo.setEmployeeId(user.getId());
            }
            // 设置供应商名称
            if (communicationVo.getProviderId() != null) {
                Provider provider = providerService.getById(communicationVo.getProviderId());
                if (provider != null) {
                    communicationVo.setProviderName(provider.getProvidername());
                }
            }
            communicationService.save(communicationVo);
            return ResultObj.ADD_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.ADD_ERROR;
        }
    }

    /**
     * 修改在线沟通记录
     */
    @RequestMapping("updateCommunication")
    public ResultObj updateCommunication(CommunicationVo communicationVo) {
        try {
            communicationService.updateById(communicationVo);
            return ResultObj.UPDATE_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.UPDATE_ERROR;
        }
    }

    /**
     * 删除在线沟通记录
     */
    @RequestMapping("deleteCommunication")
    public ResultObj deleteCommunication(Integer id) {
        try {
            communicationService.removeById(id);
            return ResultObj.DELETE_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.DELETE_ERROR;
        }
    }

    /**
     * 批量删除在线沟通记录
     */
    @RequestMapping("batchDeleteCommunication")
    public ResultObj batchDeleteCommunication(CommunicationVo communicationVo) {
        try {
            communicationService.removeById(communicationVo.getId());
            return ResultObj.DELETE_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.DELETE_ERROR;
        }
    }

    /**
     * 回复沟通
     */
    @RequestMapping("replyCommunication")
    public ResultObj replyCommunication(Integer id, String replyContent) {
        try {
            Communication communication = communicationService.getById(id);
            if (communication != null) {
                communication.setReplyContent(replyContent);
                communication.setStatus(2);
                communication.setReplyTime(new Date());
                User user = (User) WebUtils.getSession().getAttribute("user");
                if (user != null) {
                    communication.setReplyPerson(user.getName());
                }
                communicationService.updateById(communication);
                return ResultObj.UPDATE_SUCCESS;
            }
            return ResultObj.UPDATE_ERROR;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.UPDATE_ERROR;
        }
    }

    /**
     * 审核沟通
     */
    @RequestMapping("auditCommunication")
    public ResultObj auditCommunication(Integer id, Integer status) {
        try {
            Communication communication = communicationService.getById(id);
            if (communication != null) {
                communication.setStatus(status);
                communicationService.updateById(communication);
                return ResultObj.UPDATE_SUCCESS;
            }
            return ResultObj.UPDATE_ERROR;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultObj.UPDATE_ERROR;
        }
    }

}
