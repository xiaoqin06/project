package com.yeqifu.sys.mapper;

import com.yeqifu.sys.entity.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * InnoDB free: 9216 kB Mapper 接口
 * </p>
 *
 * @author luoyi-
 * @since 2019-11-25
 */
public interface NoticeMapper extends BaseMapper<Notice> {

}
