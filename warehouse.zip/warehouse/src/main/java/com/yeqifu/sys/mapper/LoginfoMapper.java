package com.yeqifu.sys.mapper;

import com.yeqifu.sys.entity.Loginfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * InnoDB free: 9216 kB Mapper 接口
 * </p>
 *
 * @author luoyi-
 * @since 2019-11-23
 */
public interface LoginfoMapper extends BaseMapper<Loginfo> {

}
