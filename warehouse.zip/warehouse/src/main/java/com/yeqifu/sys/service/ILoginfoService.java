package com.yeqifu.sys.service;

import com.yeqifu.sys.entity.Loginfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * InnoDB free: 9216 kB 服务类
 * </p>
 *
 * @author luoyi-
 * @since 2019-11-23
 */
public interface ILoginfoService extends IService<Loginfo> {

}
